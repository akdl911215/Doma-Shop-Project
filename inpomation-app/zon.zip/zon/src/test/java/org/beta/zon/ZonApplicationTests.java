package org.beta.zon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZonApplicationTests {

	@Test
	void contextLoads() {
	}

}
